/**
 * DAO�֘A
 */
package jp.terasoluna.fw.dao;